<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>OTP Demo</title>

    
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<link href="cust.css" rel="stylesheet">


    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
    <div class="container">
  <div class="row">
    <h2>Sticky Model</h2>
  </div>
    
    <div class="row">
        <button class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal">
          Launch demo modal
        </button>
    </div>
    
</div>


<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h4 class="modal-title" id="myModalLabel">otp Sample</h4>
      </div>
      <div class="modal-body">
          <form id="frm-otp" class="form-horizontal">
          <input type="hidden" name="type" value="0" />
          <fieldset class="from-details">
                <!-- Text input-->
              <div class="form-group">
                <label class="col-md-4 control-label" for="textinput">Name</label>  
                <div class="col-md-4">
                <input id="textinput" name="name" type="text" placeholder="Enter the Name" class="form-control input-md" required="">
                  
                </div>
              </div>
              <!-- Text input-->
              <div class="form-group">
                <label class="col-md-4 control-label" for="textinput">Mobile</label>  
                <div class="col-md-4">
                <input id="textinput" name="mobile" type="text" placeholder="Enter the Mobile" class="form-control input-md" required="">
                  
                </div>
              </div>

              <div class="form-group">
                <label class="col-md-4 control-label" for="textinput">Email</label>  
                <div class="col-md-4">
                <input id="textinput" name="email" type="text" placeholder="Enter the Email" class="form-control input-md" required="">
                  
                </div>
              </div>

              <div class="form-group">
                <label class="col-md-4 control-label" for="textinput">Write Message</label>  
                <div class="col-md-4">
                <textarea id="textinput" name="message" type="text" placeholder="Write Message" class="form-control input-md" required="">
                  </textarea>
                </div>
              </div>

              <div class="form-group otp-container hide">
                <label class="col-md-4 control-label" for="textinput">OTP Code</label>  
                <div class="col-md-4">
                <input id="textinput" name="otp" type="text" placeholder="Enter the Mobile" class="form-control input-md" required="">
                  
                </div>
              </div>

              <div class="msg-container hide text-center"></div>

              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                 <button type="button" id="frm-submit-btn" class="btn btn-primary">Get OTP</button>
              </div>
            </fieldset>
            </form>
      </div>
    </div>
  </div>
</div>


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Latest compiled JavaScript -->
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<script>
  
jQuery( document ).ready(function() {
    jQuery(document).on('click', '#frm-submit-btn', function(){
      $.ajax({
            type: "post",
            url: 'http://otp.parthinfotech.co/send-otp-sms.php',
            data: jQuery('#frm-otp').serialize(),
            dataType: "json",
            beforeSend:function(){
              jQuery('#frm-submit-btn').html('Please Wait ....');
            },
            success: function(responseData, textStatus, jqXHR) {
              var $type = jQuery('input[name="type"]').val();
	      
              if($type == 0 && responseData.status == 'success'){
                jQuery('input[name="type"]').val(1);
		            jQuery('input[email="type"]').val(2);
		            jQuery('input[message="type"]').val(3);
                jQuery('.otp-container').removeClass('hide').show();
                jQuery('.msg-container').html(responseData.msg);
                jQuery('.msg-container').removeClass('hide').show();
                jQuery('#frm-submit-btn').html('Send Mail');
              }
		 
              if($type == 1 && responseData.status == 'success'){
                jQuery('.from-details .form-group').hide();
                jQuery('.msg-container').html(responseData.msg);
                jQuery('.msg-container').removeClass('hide').show();
                jQuery('#frm-submit-btn').hide();
              } else {
                jQuery('.msg-container').html(responseData.msg);
                jQuery('.msg-container').removeClass('hide').show();
              }
              
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.log(errorThrown);
            }
        })
    }); 
});

</script>
  </body>
</html>
