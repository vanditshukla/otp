<?php
session_start();

if(isset($_POST)){
	if($_POST['type'] == 0){
		$rand_code = random_string('numeric',6);
		$_SESSION['otp_code'] = $rand_code;
		sendSMS($_POST['mobile'], 'Your OTP IS : ' . $rand_code);

		echo json_encode(array('status' =>'success', 'type' => 1, 'msg' => 'SMS send. Please check Mobile For OTP, .'));
	} else if($_POST['type'] == 1){
		if($_SESSION['otp_code'] == $_POST['otp']){
			sendMail($_POST);
			echo json_encode(array('status' =>'success', 'msg' => 'Hello Perfect'));
		} else {
			echo json_encode(array('status' =>'error', 'msg' => 'Invalid OTP'));
		}
	}
}

function sendSMS($mobileNumber, $msg){
	$postData = array(
	    'authkey' 	=> '88661ACMFgMgMlgbc55a61f30',
	    'sender' 	=> 'VDABRD',
	    'route' 	=> 4,
	    'country' 	=> 91,
	    'response' 	=> 'json',
	    'unicode' 	=> 1,
	    'mobiles' 	=> $mobileNumber,
	    'message' 	=> urlencode($msg),
	);

	$url = 'http://sendtosms.net/api/sendhttp.php?'. http_build_query($postData);

	$ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_exec($ch);

    if(curl_errno($ch)){
        echo 'error:' . curl_error($ch);
    }

    curl_close($ch);
	//return $output;
	return true;
}

function random_string($type = 'alnum', $len = 8) {
	switch($type)
	{
		case 'basic'	: return mt_rand();
			break;
		case 'alnum'	:
		case 'numeric'	:
		case 'nozero'	:
		case 'alpha'	:

				switch ($type)
				{
					case 'alpha'	:	$pool = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
						break;
					case 'alnum'	:	$pool = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
						break;
					case 'numeric'	:	$pool = '0123456789';
						break;
					case 'nozero'	:	$pool = '123456789';
						break;
				}

				$str = '';
				for ($i=0; $i < $len; $i++)
				{
					$str .= substr($pool, mt_rand(0, strlen($pool) -1), 1);
				}
				return $str;
			break;
		case 'unique'	:
		case 'md5'		:

					return md5(uniqid(mt_rand()));
			break;
		case 'encrypt'	:
		case 'sha1'	:

					$CI =& get_instance();
					$CI->load->helper('security');

					return do_hash(uniqid(mt_rand(), TRUE), 'sha1');
			break;
	}
}

function sendMail($data){
    $name 		= ( isset($data['name']) ) ? $data['name'] : '';;
    $email 		= ( isset($data['email']) ) ? $data['email'] : '';;
    $phone 		= ( isset($data['mobile']) ) ? $data['mobile'] : '';
    $option 	= ( isset($data['options']) ) ? implode(", " , $data['options']) : " not selected ";
    $message 	= ( isset($data['message']) ) ? htmlentities(trim(nl2br($data['message']))) : '';
          
	$message = "<table border='0' cellpadding='2' cellspacing='2' width='600'>
	<tr><td><b>Name: </b></td><td>".$name." </td></tr>
	<tr><td><b>Email:</b> </td><td> ".$email."</td></tr>
	<tr><td><b>Contact No.: </b> </td><td>".$phone ."</td></tr>
	<tr><td><b>Inquiry For: </b></td><td>".$option ."</td></tr>        
	<tr><td><b>Message: </b></td><td>".$message ."</td></tr>
	</table>";

	$str = ' You have inquiry From:'. $name.' Mobile:'. $phone.' Please check your Email.';
	sendSMS('9974245823', $str);

	$header = "From: vanditshukla3@gmail.com <Vandit Shukla> \r\n";
    $header .= "MIME-Version: 1.0\r\n";
    $header .= "Content-type: text/html\r\n";
    $return  = @mail('vanditshukla3@gmail.com', 'New Inquiery From Website', $message, $header);

    return $return;
}

