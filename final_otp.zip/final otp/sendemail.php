<?php

require_once('phpmailer/class.phpmailer.php');

        $name = $_POST['name'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
    $option   = ( isset($_POST['options']) ? implode(", " , $_POST['options']) : " not selected " );
        $message = htmlentities(trim(nl2br($_POST['message'])));
       
      

        $subject = 'New Message From shivenvirotech.com';
      
      
      
if($email){

$message = "<table border='0' cellpadding='2' cellspacing='2' width='600'>
<tr><td><b>Name: </b></td><td>".$name." </td></tr>
<tr><td><b>Email:</b> </td><td> ".$email."</td></tr>
<tr><td><b>Contact No.: </b> </td><td>".$phone ."</td></tr>
<tr><td><b>Inquiry For: </b></td><td>".$option ."</td></tr>        
<tr><td><b>Message: </b></td><td>".$message ."</td></tr>
</table>";
 //$text = "You have inquiry from".$name."And Email ID is ".$email."<br> Please check your Email.";

$str = ' You have inquiry For:' .  $option .' From:'. $_POST['name'].'Mobile:'. $_POST['phone'].' Please check your Email.';
$text = urlencode($str);

 } else{
  
$errmasg = "No Data"; 
 }
$mail = new PHPMailer();

$mail->IsSMTP();                                      // set mailer to use SMTP
$mail->Host = "smtp.gmail.com";  // specify main and backup server
$mail->Port = 578;  
$mail->SMTPAuth = true;     // turn on SMTP authentication
$mail->Username = "vanditshukla3@gmail.com";  // SMTP username
$mail->Password = "jskvens44"; // SMTP password

$mail->From = "vanditshukla3@gmail.com";
/*$mail->From = $yem;*/

$mail->FromName = $email;

$mail->AddAddress("vanditshukla3@gmail.com");                  // name is optional


$mail->WordWrap = 50;                                 // set word wrap to 50 characters
    // optional name
$mail->IsHTML(true);                                  // set email format to HTML

$mail->Subject = "New Inquiry From parthinfotech.co";
$mail->Body    = $message;
$mail->AltBody = "This is the body in plain text for non-HTML mail clients";

if(!$mail->Send())
{
   echo "Message could not be sent. <p>";
   echo "Mailer Error: " . $mail->ErrorInfo;
   exit;
}
      
      
      
  $url = "https://control.msg91.com/api/sendhttp.php?authkey=85660AcbTOxbtpg0t5566c656&mobiles=9974245823&message=$text&sender=WEBSMS&route=4&country=91";
// do sendmsg call
$file = file($url);
$ret = explode(' ',$file[0]);

if(strtolower($ret[0]) == 'message' && strtolower($ret[1]) == 'submitted'){
  $status = 'success';
}
else{
  $status='error';
}
       
     echo "<script>alert('We have successfully received your Message and will get Back to you as soon as possible.'); location.href='../contact.html';</script>";
         

?>